/* ── Config ── */
const API = '/api';
const DEFAULT_USER = 1;

/* ── State ── */
let queue = [], queueIdx = 0, currentSong = null;
let isPlaying = false, isYT = false;
let ytPlayer = null, ytReady = false, ytProgressTimer = null;
let activePl = null;

/* ── Audio element (for MP3s) ── */
const audio = new Audio();
audio.volume = 0.8;

/* ── DOM refs ── */
const playerTitle  = document.getElementById('playerTitle');
const playerArtist = document.getElementById('playerArtist');
const playerArt    = document.getElementById('playerArt');
const playBtn      = document.getElementById('playBtn');
const prevBtn      = document.getElementById('prevBtn');
const nextBtn      = document.getElementById('nextBtn');
const progressBar  = document.getElementById('progressBar');
const volumeBar    = document.getElementById('volumeBar');
const currentTime  = document.getElementById('currentTime');
const totalTime    = document.getElementById('totalTime');
const rateStatus   = document.getElementById('rateStatus');

/* ── Helpers ── */
function fmt(s) {
  if (!s || isNaN(s)) return '0:00';
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
}

function ytId(url) {
  if (!url) return null;
  const m = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/);
  return m ? m[1] : null;
}

async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json', 'X-User-Id': 'user' + DEFAULT_USER },
    ...opts
  });
  return res.json();
}

/* ── Song Card builder ── */
function songCard(song, idx, arr, showRank = false, showAdd = false) {
  const isActive = currentSong && currentSong.id === song.id;
  const vid = ytId(song.audioUrl);
  const art = vid
    ? `https://img.youtube.com/vi/${vid}/hqdefault.jpg`
    : (song.albumArt || `https://picsum.photos/seed/${song.id}/46`);

  const div = document.createElement('div');
  div.className = 'song-card' + (isActive ? ' active' : '');
  div.dataset.id = song.id;

  div.innerHTML = `
    ${showRank ? `<span class="rank">${idx + 1}</span>` : ''}
    <img src="${art}" alt="${song.title}" loading="lazy" />
    <div class="song-info">
      <div class="song-title ${isActive && isPlaying ? 'playing' : ''}">${isActive && isPlaying ? '▶ ' : ''}${song.title}</div>
      <div class="song-sub">${song.artist} · ${song.genre}</div>
    </div>
    <div class="song-meta">
      <span class="song-genre">${song.genre}</span>
      ${song.playCount ? `<span class="song-dur">▶ ${song.playCount.toLocaleString()}</span>` : ''}
    </div>
    ${showAdd ? `<button class="add-pl-btn" title="Add to playlist">+</button>` : ''}
  `;

  div.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-pl-btn')) { addToPlaylistPrompt(song); return; }
    queue = arr; queueIdx = idx;
    playSong(song);
  });

  return div;
}

function renderList(containerId, songs, showRank = false, showAdd = false) {
  const el = document.getElementById(containerId);
  el.innerHTML = '';
  if (!songs.length) { el.innerHTML = '<p class="empty">No songs found.</p>'; return; }
  songs.forEach((s, i) => el.appendChild(songCard(s, i, songs, showRank, showAdd)));
}

/* ── YouTube IFrame API ── */
function loadYTApi() {
  if (window.YT) return;
  const tag = document.createElement('script');
  tag.src = 'https://www.youtube.com/iframe_api';
  document.head.appendChild(tag);
}
window.onYouTubeIframeAPIReady = () => { ytReady = true; };
loadYTApi();

function ensureYTPlayer(videoId, autoplay = true) {
  if (ytPlayer) {
    ytPlayer.loadVideoById(videoId);
    return;
  }
  const div = document.createElement('div');
  div.id = 'yt-inner';
  document.getElementById('ytContainer').appendChild(div);

  ytPlayer = new YT.Player('yt-inner', {
    height: '1', width: '1', videoId,
    playerVars: { autoplay: autoplay ? 1 : 0, controls: 0, rel: 0 },
    events: {
      onReady: (e) => { e.target.setVolume(audio.volume * 100); if (autoplay) e.target.playVideo(); },
      onStateChange: (e) => {
        if (e.data === YT.PlayerState.ENDED) nextSong();
        if (e.data === YT.PlayerState.PLAYING) { isPlaying = true; playBtn.textContent = '⏸'; startYTProgress(); }
        if (e.data === YT.PlayerState.PAUSED)  { isPlaying = false; playBtn.textContent = '▶'; }
      }
    }
  });
}

function startYTProgress() {
  clearInterval(ytProgressTimer);
  ytProgressTimer = setInterval(() => {
    if (!ytPlayer || !ytPlayer.getCurrentTime) return;
    const cur = ytPlayer.getCurrentTime();
    const dur = ytPlayer.getDuration();
    if (dur > 0) {
      progressBar.value = cur / dur;
      currentTime.textContent = fmt(cur);
      totalTime.textContent = fmt(dur);
    }
  }, 500);
}

/* ── Playback ── */
function playSong(song) {
  currentSong = song;
  const vid = ytId(song.audioUrl);
  isYT = !!vid;

  // Update player UI
  playerTitle.textContent = song.title;
  playerArtist.textContent = song.artist;
  playerArt.src = vid
    ? `https://img.youtube.com/vi/${vid}/hqdefault.jpg`
    : (song.albumArt || `https://picsum.photos/seed/${song.id}/56`);

  // Highlight active card
  document.querySelectorAll('.song-card').forEach(c => {
    c.classList.toggle('active', c.dataset.id == song.id);
    const t = c.querySelector('.song-title');
    if (t) t.classList.toggle('playing', c.dataset.id == song.id);
  });

  if (isYT) {
    audio.pause(); audio.src = '';
    clearInterval(ytProgressTimer);
    progressBar.value = 0; currentTime.textContent = '0:00'; totalTime.textContent = '0:00';

    const tryPlay = () => {
      if (ytReady || window.YT) { ensureYTPlayer(vid); }
      else { setTimeout(tryPlay, 300); }
    };
    tryPlay();
  } else {
    // Stop YT if running
    if (ytPlayer && ytPlayer.stopVideo) ytPlayer.stopVideo();
    clearInterval(ytProgressTimer);

    audio.src = song.audioUrl;
    audio.play().catch(() => {});
  }

  isPlaying = true;
  playBtn.textContent = '⏸';

  // Notify backend (fire-and-forget)
  api(`/songs/${song.id}/play`, { method: 'POST' }).catch(() => {});
}

function togglePlay() {
  if (!currentSong) return;
  if (isYT && ytPlayer) {
    isPlaying ? ytPlayer.pauseVideo() : ytPlayer.playVideo();
  } else {
    isPlaying ? audio.pause() : audio.play();
  }
  isPlaying = !isPlaying;
  playBtn.textContent = isPlaying ? '⏸' : '▶';
}

function nextSong() {
  if (!queue.length) return;
  queueIdx = (queueIdx + 1) % queue.length;
  playSong(queue[queueIdx]);
}

function prevSong() {
  if (!isYT && audio.currentTime > 3) { audio.currentTime = 0; return; }
  queueIdx = (queueIdx - 1 + queue.length) % queue.length;
  playSong(queue[queueIdx]);
}

/* ── HTML Audio events ── */
audio.addEventListener('timeupdate', () => {
  if (isYT) return;
  const dur = audio.duration || 1;
  progressBar.value = audio.currentTime / dur;
  currentTime.textContent = fmt(audio.currentTime);
  totalTime.textContent = fmt(audio.duration);
});
audio.addEventListener('ended', nextSong);

/* ── Controls ── */
playBtn.addEventListener('click', togglePlay);
nextBtn.addEventListener('click', nextSong);
prevBtn.addEventListener('click', prevSong);

progressBar.addEventListener('input', () => {
  const v = parseFloat(progressBar.value);
  if (isYT && ytPlayer) { ytPlayer.seekTo(v * ytPlayer.getDuration(), true); }
  else { audio.currentTime = v * audio.duration; }
});

volumeBar.addEventListener('input', () => {
  const v = parseFloat(volumeBar.value);
  audio.volume = v;
  if (ytPlayer && ytPlayer.setVolume) ytPlayer.setVolume(v * 100);
});

/* ── Data loaders ── */
async function loadHome() {
  const res = await api('/songs');
  const songs = res.data || [];
  renderList('allSongs', songs, false, true);
}

async function loadTrending() {
  const res = await api('/recommendations?userId=' + DEFAULT_USER + '&limit=10');
  const songs = res.data || [];
  renderList('trendingSongs', songs, true, false);
}

async function loadRecommendations() {
  const res = await api('/recommendations/personalized?userId=' + DEFAULT_USER);
  const songs = res.data || [];
  renderList('recSongs', songs, false, true);
}

async function loadPlaylists() {
  const res = await api('/playlists/user/' + DEFAULT_USER);
  const pls = res.data || [];
  const grid = document.getElementById('playlistGrid');
  grid.innerHTML = '';
  if (!pls.length) { grid.innerHTML = '<p class="empty">No playlists yet.</p>'; return; }
  pls.forEach(pl => {
    const card = document.createElement('div');
    card.className = 'pl-card';
    card.innerHTML = `
      <div>
        <div class="pl-card-name">📋 ${pl.name}</div>
        <div class="pl-card-count">${(pl.songs || []).length} songs</div>
      </div>
      <button class="pl-del" data-id="${pl.id}" title="Delete">🗑</button>
    `;
    card.addEventListener('click', (e) => {
      if (e.target.classList.contains('pl-del')) {
        deletePl(pl.id); return;
      }
      openPlaylist(pl);
    });
    grid.appendChild(card);
  });
}

async function openPlaylist(pl) {
  activePl = pl;
  const res = await api('/playlists/' + pl.id);
  const full = res.data || pl;
  const songs = full.songs || [];
  const container = document.getElementById('plSongs');
  container.innerHTML = `<h3 style="margin-bottom:12px">📋 ${full.name}</h3>`;
  if (!songs.length) { container.innerHTML += '<p class="empty">No songs in this playlist.</p>'; return; }
  const list = document.createElement('div');
  list.className = 'song-list';
  songs.forEach((s, i) => list.appendChild(songCard(s, i, songs)));
  container.appendChild(list);
}

async function deletePl(id) {
  await api('/playlists/' + id, { method: 'DELETE' });
  loadPlaylists();
}

async function createPlaylist() {
  const name = document.getElementById('plName').value.trim();
  if (!name) return;
  await api('/playlists', {
    method: 'POST',
    body: JSON.stringify({ name, ownerId: DEFAULT_USER })
  });
  document.getElementById('plName').value = '';
  loadPlaylists();
}

async function addToPlaylistPrompt(song) {
  const res = await api('/playlists/user/' + DEFAULT_USER);
  const pls = res.data || [];
  if (!pls.length) { alert('Create a playlist first!'); return; }
  const names = pls.map((p, i) => `${i + 1}. ${p.name}`).join('\n');
  const choice = prompt(`Add "${song.title}" to:\n${names}\n\nEnter number:`);
  if (!choice) return;
  const pl = pls[parseInt(choice) - 1];
  if (!pl) return;
  await api(`/playlists/${pl.id}/songs/${song.id}`, { method: 'POST' });
  alert(`Added to "${pl.name}"!`);
}

async function loadRateStatus() {
  try {
    const res = await api('/rate-limit/status');
    const d = res.data || {};
    rateStatus.textContent = `Requests: ${d.remaining}/${d.limit} remaining`;
  } catch {}
}

/* ── Navigation ── */
const views = { home: loadHome, trending: loadTrending, recommendations: loadRecommendations, playlists: loadPlaylists };

document.querySelectorAll('.nav-item').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const view = link.dataset.view;
    document.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    link.classList.add('active');
    document.getElementById('view-' + view).classList.add('active');
    if (views[view]) views[view]();
  });
});

/* ── Search ── */
document.getElementById('searchForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const q = document.getElementById('searchInput').value.trim();
  if (!q) return;

  // Switch to home view and show results
  document.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelector('[data-view="home"]').classList.add('active');
  document.getElementById('view-home').classList.add('active');

  document.getElementById('view-home').querySelector('h2').textContent = `Results for "${q}"`;
  const res = await api('/songs/search?q=' + encodeURIComponent(q));
  const songs = res.data || res || [];
  renderList('allSongs', Array.isArray(songs) ? songs : [], false, true);
});

/* ── Strategy buttons ── */
document.querySelectorAll('.strat-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    document.querySelectorAll('.strat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    await api('/recommendations/strategy?strategy=' + btn.dataset.s, { method: 'POST' });
    loadRecommendations();
  });
});

/* ── Create playlist ── */
document.getElementById('createPlBtn').addEventListener('click', createPlaylist);
document.getElementById('plName').addEventListener('keydown', (e) => { if (e.key === 'Enter') createPlaylist(); });

/* ── Theme toggle ── */
document.getElementById('themeBtn').addEventListener('click', () => {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  document.getElementById('themeBtn').textContent = isDark ? '🌙 Dark Mode' : '☀️ Light Mode';
});

/* ── Init ── */
loadHome();
loadRateStatus();
setInterval(loadRateStatus, 30000);
