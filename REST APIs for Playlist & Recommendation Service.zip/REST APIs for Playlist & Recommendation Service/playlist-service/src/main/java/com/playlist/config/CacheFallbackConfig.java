package com.playlist.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;

/**
 * Falls back to in-memory cache if Redis is not available.
 * This allows the app to run without a Redis instance for local dev.
 */
@Slf4j
@Configuration
public class CacheFallbackConfig {

    @Bean
    @ConditionalOnMissingBean(RedisConnectionFactory.class)
    public CacheManager fallbackCacheManager() {
        log.warn("Redis not available — using in-memory ConcurrentMapCacheManager");
        return new ConcurrentMapCacheManager("playlists", "recommendations", "songs");
    }
}
