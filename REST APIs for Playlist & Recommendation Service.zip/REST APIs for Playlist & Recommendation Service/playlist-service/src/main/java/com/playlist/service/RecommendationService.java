package com.playlist.service;

import com.playlist.model.Song;
import com.playlist.recommendation.RecommendationContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RecommendationService {

    private final RecommendationContext context;

    /**
     * Get recommendations using the currently active strategy.
     * Result is cached in Redis under "recommendations::{userId}".
     */
    @Cacheable(value = "recommendations", key = "#userId + '_' + #limit")
    public List<Song> getRecommendations(Long userId, int limit) {
        log.info("Generating recommendations for user {} using strategy: {}",
                userId, context.getActiveStrategyName());
        return context.recommend(userId, limit);
    }

    /**
     * Multi-strategy: runs all strategies and merges results.
     * Cached separately.
     */
    @Cacheable(value = "recommendations", key = "'personalized_' + #userId")
    public List<Song> getPersonalizedRecommendations(Long userId) {
        log.info("Generating personalized (multi-strategy) recommendations for user {}", userId);
        return context.recommendAll(userId, 5);
    }

    /** Switch active strategy and clear recommendation cache */
    @CacheEvict(value = "recommendations", allEntries = true)
    public void switchStrategy(String strategyName) {
        context.setStrategy(strategyName);
    }

    public String getActiveStrategy() {
        return context.getActiveStrategyName();
    }

    public List<String> getAvailableStrategies() {
        return context.getAvailableStrategies();
    }
}
