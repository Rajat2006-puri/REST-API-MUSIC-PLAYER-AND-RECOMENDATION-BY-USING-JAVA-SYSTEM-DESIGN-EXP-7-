package com.playlist.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Playlist & Recommendation Service API")
                        .description("REST APIs for playlist management and music recommendations " +
                                "with rate limiting, caching, and design patterns.")
                        .version("1.0.0")
                        .contact(new Contact().name("Dev Team").email("dev@playlist.com"))
                        .license(new License().name("MIT")));
    }
}
