package com.playlist.service;

import com.playlist.dto.PlaylistRequest;
import com.playlist.exception.ResourceNotFoundException;
import com.playlist.model.Playlist;
import com.playlist.model.Song;
import com.playlist.model.User;
import com.playlist.observer.PlaylistEventPublisher;
import com.playlist.repository.PlaylistRepository;
import com.playlist.repository.SongRepository;
import com.playlist.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PlaylistService {

    private final PlaylistRepository playlistRepository;
    private final SongRepository songRepository;
    private final UserRepository userRepository;
    private final PlaylistEventPublisher eventPublisher;

    /**
     * Create a new playlist and notify observers.
     */
    @Transactional
    public Playlist createPlaylist(PlaylistRequest request) {
        Playlist playlist = new Playlist();
        playlist.setName(request.getName());
        playlist.setDescription(request.getDescription());

        if (request.getOwnerId() != null) {
            User owner = userRepository.findById(request.getOwnerId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found: " + request.getOwnerId()));
            playlist.setOwner(owner);
        }

        Playlist saved = playlistRepository.save(playlist);
        log.info("Created playlist id={} name='{}'", saved.getId(), saved.getName());

        // Notify observers (Email + Push)
        eventPublisher.notifyCreated(saved);
        return saved;
    }

    /**
     * Cache-Aside Pattern:
     * Spring checks Redis first. On cache miss, this method runs and result is stored in Redis.
     */
    @Cacheable(value = "playlists", key = "#id")
    public Playlist getPlaylist(Long id) {
        log.debug("Cache MISS for playlist id={} — fetching from DB", id);
        return playlistRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found: " + id));
    }

    /**
     * Update playlist and evict stale cache entry.
     */
    @Transactional
    @CacheEvict(value = "playlists", key = "#id")
    public Playlist updatePlaylist(Long id, PlaylistRequest request) {
        Playlist playlist = playlistRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found: " + id));
        playlist.setName(request.getName());
        playlist.setDescription(request.getDescription());
        log.info("Updated playlist id={}", id);
        return playlistRepository.save(playlist);
    }

    /**
     * Delete playlist and evict from cache.
     */
    @Transactional
    @CacheEvict(value = "playlists", key = "#id")
    public void deletePlaylist(Long id) {
        if (!playlistRepository.existsById(id)) {
            throw new ResourceNotFoundException("Playlist not found: " + id);
        }
        playlistRepository.deleteById(id);
        log.info("Deleted playlist id={}", id);
    }

    /**
     * Add a song to a playlist, evict cache, notify observers.
     */
    @Transactional
    @CacheEvict(value = "playlists", key = "#playlistId")
    public Playlist addSong(Long playlistId, Long songId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found: " + playlistId));
        Song song = songRepository.findById(songId)
                .orElseThrow(() -> new ResourceNotFoundException("Song not found: " + songId));

        if (!playlist.getSongs().contains(song)) {
            playlist.getSongs().add(song);
            playlistRepository.save(playlist);
            eventPublisher.notifySongAdded(playlist, songId);
            log.info("Added song {} to playlist {}", songId, playlistId);
        }
        return playlist;
    }

    /**
     * Remove a song from a playlist, evict cache, notify observers.
     */
    @Transactional
    @CacheEvict(value = "playlists", key = "#playlistId")
    public Playlist removeSong(Long playlistId, Long songId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found: " + playlistId));

        boolean removed = playlist.getSongs().removeIf(s -> s.getId().equals(songId));
        if (removed) {
            playlistRepository.save(playlist);
            eventPublisher.notifySongRemoved(playlist, songId);
            log.info("Removed song {} from playlist {}", songId, playlistId);
        }
        return playlist;
    }

    public List<Playlist> getPlaylistsByUser(Long userId) {
        return playlistRepository.findByOwnerId(userId);
    }
}
