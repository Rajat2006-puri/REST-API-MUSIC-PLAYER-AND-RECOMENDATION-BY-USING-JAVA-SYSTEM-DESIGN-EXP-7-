package com.playlist.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.io.Serializable;

@Entity
@Table(name = "songs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Song implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Title is required")
    @Column(nullable = false)
    private String title;

    @NotBlank(message = "Artist is required")
    @Column(nullable = false)
    private String artist;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Genre genre;

    @Column(name = "play_count")
    private int playCount = 0;

    private double rating = 0.0;

    @Column(name = "audio_url")
    private String audioUrl;

    @Column(name = "album_art")
    private String albumArt;

    public enum Genre {
        POP, ROCK, HIP_HOP, INDIE, JAZZ, CLASSICAL, ELECTRONIC, BOLLYWOOD
    }
}

