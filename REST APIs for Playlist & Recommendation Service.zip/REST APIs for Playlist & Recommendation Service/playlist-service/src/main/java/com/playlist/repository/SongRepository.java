package com.playlist.repository;

import com.playlist.model.Song;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SongRepository extends JpaRepository<Song, Long> {

    List<Song> findByGenre(Song.Genre genre);

    // Top N songs by play count
    @Query("SELECT s FROM Song s ORDER BY s.playCount DESC")
    List<Song> findTopByPlayCount();

    // Top N songs by rating
    @Query("SELECT s FROM Song s ORDER BY s.rating DESC")
    List<Song> findTopByRating();

    List<Song> findByArtist(String artist);
}
