package com.playlist.recommendation;

import com.playlist.model.Song;

import java.util.List;

/**
 * Strategy Pattern interface for recommendation algorithms.
 * Each implementation provides a different recommendation approach.
 */
public interface RecommendationStrategy {

    /**
     * @param userId  the user to recommend for
     * @param limit   max number of songs to return
     */
    List<Song> recommend(Long userId, int limit);

    String getStrategyName();
}
