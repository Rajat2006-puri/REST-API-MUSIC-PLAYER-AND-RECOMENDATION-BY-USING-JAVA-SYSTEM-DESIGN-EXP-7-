package com.playlist.dto;

import lombok.Data;

import jakarta.validation.constraints.NotBlank;

@Data
public class PlaylistRequest {

    @NotBlank(message = "Name is required")
    private String name;

    private String description;

    private Long ownerId;
}

