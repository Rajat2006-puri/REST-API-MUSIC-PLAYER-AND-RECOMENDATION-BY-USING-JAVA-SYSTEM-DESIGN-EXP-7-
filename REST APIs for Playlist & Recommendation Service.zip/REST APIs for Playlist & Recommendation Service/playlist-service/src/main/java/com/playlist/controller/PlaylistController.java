package com.playlist.controller;

import com.playlist.dto.ApiResponse;
import com.playlist.dto.PlaylistRequest;
import com.playlist.model.Playlist;
import com.playlist.service.PlaylistService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/playlists")
@RequiredArgsConstructor
@Tag(name = "Playlist", description = "Playlist management APIs")
public class PlaylistController {

    private final PlaylistService playlistService;

    @Operation(summary = "Create a new playlist")
    @PostMapping
    public ResponseEntity<ApiResponse<Playlist>> create(@Valid @RequestBody PlaylistRequest request) {
        Playlist playlist = playlistService.createPlaylist(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Playlist created", playlist));
    }

    @Operation(summary = "Get playlist by ID (cached)")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Playlist>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(playlistService.getPlaylist(id)));
    }

    @Operation(summary = "Update playlist")
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Playlist>> update(
            @PathVariable Long id,
            @Valid @RequestBody PlaylistRequest request) {
        return ResponseEntity.ok(ApiResponse.ok("Playlist updated", playlistService.updatePlaylist(id, request)));
    }

    @Operation(summary = "Delete playlist")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        playlistService.deletePlaylist(id);
        return ResponseEntity.ok(ApiResponse.ok("Playlist deleted", null));
    }

    @Operation(summary = "Add song to playlist")
    @PostMapping("/{id}/songs/{songId}")
    public ResponseEntity<ApiResponse<Playlist>> addSong(
            @PathVariable Long id,
            @PathVariable Long songId) {
        return ResponseEntity.ok(ApiResponse.ok("Song added", playlistService.addSong(id, songId)));
    }

    @Operation(summary = "Remove song from playlist")
    @DeleteMapping("/{id}/songs/{songId}")
    public ResponseEntity<ApiResponse<Playlist>> removeSong(
            @PathVariable Long id,
            @PathVariable Long songId) {
        return ResponseEntity.ok(ApiResponse.ok("Song removed", playlistService.removeSong(id, songId)));
    }

    @Operation(summary = "Get all playlists for a user")
    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse<List<Playlist>>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok(playlistService.getPlaylistsByUser(userId)));
    }
}

