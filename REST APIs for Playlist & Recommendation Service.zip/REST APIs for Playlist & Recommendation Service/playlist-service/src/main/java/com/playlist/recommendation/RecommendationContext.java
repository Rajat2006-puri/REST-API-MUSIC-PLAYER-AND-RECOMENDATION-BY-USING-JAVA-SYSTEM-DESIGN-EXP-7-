package com.playlist.recommendation;

import com.playlist.model.Song;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Strategy Context — holds the active strategy and allows dynamic switching.
 * All available strategies are injected and stored by name.
 */
@Slf4j
@Component
public class RecommendationContext {

    private final Map<String, RecommendationStrategy> strategies;
    private RecommendationStrategy activeStrategy;

    public RecommendationContext(List<RecommendationStrategy> strategyList) {
        // Build a map: strategyName -> strategy instance
        this.strategies = strategyList.stream()
                .collect(Collectors.toMap(RecommendationStrategy::getStrategyName, Function.identity()));
        // Default strategy
        this.activeStrategy = strategies.get("POPULARITY");
        log.info("RecommendationContext initialized with strategies: {}", strategies.keySet());
    }

    /** Dynamically switch strategy at runtime */
    public void setStrategy(String strategyName) {
        RecommendationStrategy strategy = strategies.get(strategyName.toUpperCase());
        if (strategy == null) {
            throw new IllegalArgumentException("Unknown strategy: " + strategyName +
                    ". Available: " + strategies.keySet());
        }
        this.activeStrategy = strategy;
        log.info("Switched recommendation strategy to: {}", strategyName);
    }

    public List<Song> recommend(Long userId, int limit) {
        return activeStrategy.recommend(userId, limit);
    }

    public String getActiveStrategyName() {
        return activeStrategy.getStrategyName();
    }

    public List<String> getAvailableStrategies() {
        return List.copyOf(strategies.keySet());
    }

    /**
     * Multi-strategy: run all strategies and merge results (deduplicated).
     */
    public List<Song> recommendAll(Long userId, int limitPerStrategy) {
        return strategies.values().stream()
                .flatMap(s -> s.recommend(userId, limitPerStrategy).stream())
                .distinct()
                .limit((long) limitPerStrategy * 2)
                .collect(Collectors.toList());
    }
}
