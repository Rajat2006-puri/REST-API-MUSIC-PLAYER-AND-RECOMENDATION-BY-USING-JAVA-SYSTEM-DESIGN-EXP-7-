package com.playlist.ratelimit;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages per-user token buckets.
 * Each user gets their own bucket created on first request.
 */
@Slf4j
@Service
public class RateLimiterService {

    @Value("${ratelimit.capacity:10}")
    private int capacity;

    @Value("${ratelimit.refill-tokens:10}")
    private int refillTokens;

    @Value("${ratelimit.refill-seconds:60}")
    private int refillSeconds;

    // userId -> TokenBucket
    private final Map<String, TokenBucket> buckets = new ConcurrentHashMap<>();

    /**
     * Check and consume a token for the given user.
     * @return true if request is allowed
     */
    public boolean isAllowed(String userId) {
        TokenBucket bucket = buckets.computeIfAbsent(userId,
                id -> new TokenBucket(capacity, refillTokens, refillSeconds));
        return bucket.tryConsume();
    }

    public RateLimitStatus getStatus(String userId) {
        TokenBucket bucket = buckets.computeIfAbsent(userId,
                id -> new TokenBucket(capacity, refillTokens, refillSeconds));
        return new RateLimitStatus(capacity, bucket.getRemaining(), refillSeconds);
    }

    public static class RateLimitStatus {
        private final int limit;
        private final int remaining;
        private final int refillSeconds;

        public RateLimitStatus(int limit, int remaining, int refillSeconds) {
            this.limit = limit;
            this.remaining = remaining;
            this.refillSeconds = refillSeconds;
        }

        public int limit() { return limit; }
        public int remaining() { return remaining; }
        public int refillSeconds() { return refillSeconds; }
    }
}
