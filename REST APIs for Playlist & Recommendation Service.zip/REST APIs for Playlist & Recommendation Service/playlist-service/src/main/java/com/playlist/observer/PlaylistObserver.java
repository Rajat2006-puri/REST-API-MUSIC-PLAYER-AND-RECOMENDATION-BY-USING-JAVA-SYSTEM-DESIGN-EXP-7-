package com.playlist.observer;

import com.playlist.model.Playlist;

/**
 * Observer Pattern interface.
 * Observers are notified on playlist lifecycle events.
 */
public interface PlaylistObserver {

    void onPlaylistCreated(Playlist playlist);

    void onSongAdded(Playlist playlist, Long songId);

    void onSongRemoved(Playlist playlist, Long songId);
}
