package com.playlist.observer;

import com.playlist.model.Playlist;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Simulates sending email notifications on playlist events.
 * In production, replace log statements with actual email service calls.
 */
@Slf4j
@Component
public class EmailNotificationObserver implements PlaylistObserver {

    @Override
    public void onPlaylistCreated(Playlist playlist) {
        log.info("[EMAIL] Playlist created: '{}' by user id={}",
                playlist.getName(),
                playlist.getOwner() != null ? playlist.getOwner().getId() : "unknown");
    }

    @Override
    public void onSongAdded(Playlist playlist, Long songId) {
        log.info("[EMAIL] Song {} added to playlist '{}'", songId, playlist.getName());
    }

    @Override
    public void onSongRemoved(Playlist playlist, Long songId) {
        log.info("[EMAIL] Song {} removed from playlist '{}'", songId, playlist.getName());
    }
}
