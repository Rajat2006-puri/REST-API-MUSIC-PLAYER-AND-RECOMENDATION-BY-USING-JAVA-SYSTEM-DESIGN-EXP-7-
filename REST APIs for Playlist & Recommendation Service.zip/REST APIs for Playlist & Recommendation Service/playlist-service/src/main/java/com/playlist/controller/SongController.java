package com.playlist.controller;

import com.playlist.dto.ApiResponse;
import com.playlist.exception.ResourceNotFoundException;
import com.playlist.model.Song;
import com.playlist.repository.SongRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/songs")
@RequiredArgsConstructor
@Tag(name = "Songs", description = "Song management APIs")
public class SongController {

    private final SongRepository songRepository;

    @Operation(summary = "Get all songs")
    @GetMapping
    @Cacheable(value = "songs", key = "'all'")
    public ResponseEntity<ApiResponse<List<Song>>> getAll() {
        return ResponseEntity.ok(ApiResponse.ok(songRepository.findAll()));
    }

    @Operation(summary = "Search songs by title or artist")
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<Song>>> search(@RequestParam String q) {
        String lower = q.toLowerCase();
        List<Song> results = songRepository.findAll().stream()
                .filter(s -> s.getTitle().toLowerCase().contains(lower)
                          || s.getArtist().toLowerCase().contains(lower))
                .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.ok(results));
    }

    @Operation(summary = "Get song by ID")
    @GetMapping("/{id}")
    @Cacheable(value = "songs", key = "#id")
    public ResponseEntity<ApiResponse<Song>> getById(@PathVariable Long id) {
        Song song = songRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Song not found: " + id));
        return ResponseEntity.ok(ApiResponse.ok(song));
    }

    @Operation(summary = "Record a play (increment play count)")
    @PostMapping("/{id}/play")
    public ResponseEntity<ApiResponse<Song>> play(@PathVariable Long id) {
        Song song = songRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Song not found: " + id));
        song.setPlayCount(song.getPlayCount() + 1);
        return ResponseEntity.ok(ApiResponse.ok(songRepository.save(song)));
    }

    @Operation(summary = "Create a new song")
    @PostMapping
    public ResponseEntity<ApiResponse<Song>> create(@Valid @RequestBody Song song) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Song created", songRepository.save(song)));
    }
}

