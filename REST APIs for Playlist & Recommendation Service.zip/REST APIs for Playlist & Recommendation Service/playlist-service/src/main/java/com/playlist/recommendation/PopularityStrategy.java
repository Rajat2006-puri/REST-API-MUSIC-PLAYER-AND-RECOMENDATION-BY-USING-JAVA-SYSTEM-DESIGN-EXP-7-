package com.playlist.recommendation;

import com.playlist.model.Song;
import com.playlist.repository.SongRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Recommends songs based on global play count (most popular first).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PopularityStrategy implements RecommendationStrategy {

    private final SongRepository songRepository;

    @Override
    public List<Song> recommend(Long userId, int limit) {
        log.debug("PopularityStrategy: recommending top {} songs for user {}", limit, userId);
        return songRepository.findTopByPlayCount()
                .stream()
                .limit(limit)
                .collect(Collectors.toList());
    }

    @Override
    public String getStrategyName() {
        return "POPULARITY";
    }
}
