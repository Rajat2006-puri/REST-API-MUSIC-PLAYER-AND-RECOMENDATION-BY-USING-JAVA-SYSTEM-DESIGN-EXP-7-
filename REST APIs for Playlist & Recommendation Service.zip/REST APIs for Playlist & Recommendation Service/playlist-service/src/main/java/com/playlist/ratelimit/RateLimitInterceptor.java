package com.playlist.ratelimit;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Intercepts all /api/recommendations requests and applies rate limiting.
 * Adds X-RateLimit-* headers to every response.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RateLimitInterceptor implements HandlerInterceptor {

    private final RateLimiterService rateLimiterService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        // Use X-User-Id header or fall back to IP address
        String userId = request.getHeader("X-User-Id");
        if (userId == null || userId.isBlank()) {
            userId = request.getRemoteAddr();
        }

        RateLimiterService.RateLimitStatus status = rateLimiterService.getStatus(userId);

        // Set rate limit headers
        response.setHeader("X-RateLimit-Limit", String.valueOf(status.limit()));
        response.setHeader("X-RateLimit-Remaining", String.valueOf(status.remaining()));
        response.setHeader("X-RateLimit-Reset", String.valueOf(status.refillSeconds()));

        if (!rateLimiterService.isAllowed(userId)) {
            log.warn("Rate limit exceeded for user: {}", userId);
            response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
            response.setContentType("application/json");
            response.getWriter().write(
                "{\"success\":false,\"error\":\"Rate limit exceeded. Try again in " +
                status.refillSeconds() + " seconds.\"}"
            );
            return false;
        }

        return true;
    }
}

