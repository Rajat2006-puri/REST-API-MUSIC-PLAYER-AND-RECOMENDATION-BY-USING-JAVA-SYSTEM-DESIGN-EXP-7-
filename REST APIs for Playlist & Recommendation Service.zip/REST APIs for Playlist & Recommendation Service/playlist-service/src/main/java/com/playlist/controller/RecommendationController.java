package com.playlist.controller;

import com.playlist.dto.ApiResponse;
import com.playlist.model.Song;
import com.playlist.service.RecommendationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/recommendations")
@RequiredArgsConstructor
@Tag(name = "Recommendations", description = "Music recommendation APIs (rate limited)")
public class RecommendationController {

    private final RecommendationService recommendationService;

    @Operation(summary = "Get recommendations using active strategy")
    @GetMapping
    public ResponseEntity<ApiResponse<List<Song>>> getRecommendations(
            @RequestParam(defaultValue = "1") Long userId,
            @RequestParam(defaultValue = "10") int limit) {
        List<Song> songs = recommendationService.getRecommendations(userId, limit);
        return ResponseEntity.ok(ApiResponse.ok(
                "Strategy: " + recommendationService.getActiveStrategy(), songs));
    }

    @Operation(summary = "Get personalized recommendations (all strategies merged)")
    @GetMapping("/personalized")
    public ResponseEntity<ApiResponse<List<Song>>> getPersonalized(
            @RequestParam(defaultValue = "1") Long userId) {
        return ResponseEntity.ok(ApiResponse.ok(
                "Personalized recommendations", recommendationService.getPersonalizedRecommendations(userId)));
    }

    @Operation(summary = "Switch recommendation strategy")
    @PostMapping("/strategy")
    public ResponseEntity<ApiResponse<Map<String, Object>>> switchStrategy(
            @RequestParam String strategy) {
        recommendationService.switchStrategy(strategy);
        return ResponseEntity.ok(ApiResponse.ok("Strategy switched", Map.of(
                "active", recommendationService.getActiveStrategy(),
                "available", recommendationService.getAvailableStrategies()
        )));
    }

    @Operation(summary = "Get current strategy info")
    @GetMapping("/strategy")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getStrategy() {
        return ResponseEntity.ok(ApiResponse.ok(Map.of(
                "active", recommendationService.getActiveStrategy(),
                "available", recommendationService.getAvailableStrategies()
        )));
    }
}
