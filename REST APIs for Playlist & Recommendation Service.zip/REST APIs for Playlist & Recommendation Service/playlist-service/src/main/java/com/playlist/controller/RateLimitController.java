package com.playlist.controller;

import com.playlist.dto.ApiResponse;
import com.playlist.ratelimit.RateLimiterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/api/rate-limit")
@RequiredArgsConstructor
@Tag(name = "Rate Limit", description = "Check rate limit status")
public class RateLimitController {

    private final RateLimiterService rateLimiterService;

    @Operation(summary = "Check rate limit status for current user")
    @GetMapping("/status")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getStatus(HttpServletRequest request) {
        String userId = request.getHeader("X-User-Id");
        if (userId == null || userId.isBlank()) userId = request.getRemoteAddr();

        RateLimiterService.RateLimitStatus status = rateLimiterService.getStatus(userId);
        return ResponseEntity.ok(ApiResponse.ok(Map.of(
                "userId", userId,
                "limit", status.limit(),
                "remaining", status.remaining(),
                "refillSeconds", status.refillSeconds()
        )));
    }
}

