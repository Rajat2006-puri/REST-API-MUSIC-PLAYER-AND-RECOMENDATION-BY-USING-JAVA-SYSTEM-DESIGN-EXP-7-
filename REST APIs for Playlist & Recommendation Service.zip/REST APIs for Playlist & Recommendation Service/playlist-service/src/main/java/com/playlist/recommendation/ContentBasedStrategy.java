package com.playlist.recommendation;

import com.playlist.model.Playlist;
import com.playlist.model.Song;
import com.playlist.repository.PlaylistRepository;
import com.playlist.repository.SongRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Content-Based Filtering:
 * Analyzes genres in the user's playlists and recommends
 * songs from the most-listened genres that aren't already in their playlists.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ContentBasedStrategy implements RecommendationStrategy {

    private final PlaylistRepository playlistRepository;
    private final SongRepository songRepository;

    @Override
    public List<Song> recommend(Long userId, int limit) {
        log.debug("ContentBasedStrategy: recommending for user {}", userId);

        List<Playlist> userPlaylists = playlistRepository.findByOwnerId(userId);

        // Collect all songs already in user's playlists
        Set<Long> ownedSongIds = userPlaylists.stream()
                .flatMap(p -> p.getSongs().stream())
                .map(Song::getId)
                .collect(Collectors.toSet());

        // Tally genre frequency
        Map<Song.Genre, Long> genreCount = userPlaylists.stream()
                .flatMap(p -> p.getSongs().stream())
                .collect(Collectors.groupingBy(Song::getGenre, Collectors.counting()));

        if (genreCount.isEmpty()) {
            // No history — fall back to top rated
            return songRepository.findTopByRating().stream().limit(limit).collect(Collectors.toList());
        }

        // Get top 2 genres
        List<Song.Genre> topGenres = genreCount.entrySet().stream()
                .sorted(Map.Entry.<Song.Genre, Long>comparingByValue().reversed())
                .limit(2)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // Find songs in those genres not already owned
        List<Song> recommendations = new ArrayList<>();
        for (Song.Genre genre : topGenres) {
            songRepository.findByGenre(genre).stream()
                    .filter(s -> !ownedSongIds.contains(s.getId()))
                    .forEach(recommendations::add);
        }

        // Pad with popular songs if not enough
        if (recommendations.size() < limit) {
            songRepository.findTopByPlayCount().stream()
                    .filter(s -> !ownedSongIds.contains(s.getId()) && !recommendations.contains(s))
                    .limit(limit - recommendations.size())
                    .forEach(recommendations::add);
        }

        return recommendations.stream().limit(limit).collect(Collectors.toList());
    }

    @Override
    public String getStrategyName() {
        return "CONTENT_BASED";
    }
}
