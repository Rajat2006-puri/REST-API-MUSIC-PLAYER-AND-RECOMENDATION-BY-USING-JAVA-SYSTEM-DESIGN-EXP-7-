package com.playlist.observer;

import com.playlist.model.Playlist;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Manages all registered observers and broadcasts events to them.
 */
@Slf4j
@Component
public class PlaylistEventPublisher {

    private final List<PlaylistObserver> observers;

    // Spring injects all PlaylistObserver beans automatically
    public PlaylistEventPublisher(List<PlaylistObserver> observers) {
        this.observers = observers;
        log.info("PlaylistEventPublisher registered {} observers", observers.size());
    }

    public void notifyCreated(Playlist playlist) {
        observers.forEach(o -> o.onPlaylistCreated(playlist));
    }

    public void notifySongAdded(Playlist playlist, Long songId) {
        observers.forEach(o -> o.onSongAdded(playlist, songId));
    }

    public void notifySongRemoved(Playlist playlist, Long songId) {
        observers.forEach(o -> o.onSongRemoved(playlist, songId));
    }
}
