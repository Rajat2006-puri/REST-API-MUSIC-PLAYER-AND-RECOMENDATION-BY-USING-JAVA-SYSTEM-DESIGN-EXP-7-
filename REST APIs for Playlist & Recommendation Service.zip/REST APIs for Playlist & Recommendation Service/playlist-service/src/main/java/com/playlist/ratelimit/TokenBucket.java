package com.playlist.ratelimit;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Token Bucket Algorithm implementation.
 *
 * - Bucket holds up to `capacity` tokens.
 * - Tokens refill at a fixed rate (refillTokens per refillSeconds).
 * - Each request consumes 1 token.
 * - If no tokens available → request is rejected (HTTP 429).
 */
@Slf4j
@Getter
public class TokenBucket {

    private final int capacity;
    private final int refillTokens;
    private final long refillIntervalMs;

    private final AtomicInteger tokens;
    private volatile long lastRefillTime;

    public TokenBucket(int capacity, int refillTokens, int refillSeconds) {
        this.capacity = capacity;
        this.refillTokens = refillTokens;
        this.refillIntervalMs = refillSeconds * 1000L;
        this.tokens = new AtomicInteger(capacity);
        this.lastRefillTime = Instant.now().toEpochMilli();
    }

    /**
     * Try to consume one token.
     * @return true if allowed, false if rate limit exceeded
     */
    public synchronized boolean tryConsume() {
        refill();
        if (tokens.get() > 0) {
            tokens.decrementAndGet();
            return true;
        }
        log.warn("Rate limit exceeded. Tokens: 0/{}", capacity);
        return false;
    }

    /** Refill tokens based on elapsed time */
    private void refill() {
        long now = Instant.now().toEpochMilli();
        long elapsed = now - lastRefillTime;
        if (elapsed >= refillIntervalMs) {
            int tokensToAdd = (int) (elapsed / refillIntervalMs) * refillTokens;
            int newTokens = Math.min(capacity, tokens.get() + tokensToAdd);
            tokens.set(newTokens);
            lastRefillTime = now;
            log.debug("Token bucket refilled: {}/{}", newTokens, capacity);
        }
    }

    public int getRemaining() {
        refill();
        return tokens.get();
    }
}
