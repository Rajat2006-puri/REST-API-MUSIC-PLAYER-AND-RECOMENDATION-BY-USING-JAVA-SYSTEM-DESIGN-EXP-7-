package com.playlist.observer;

import com.playlist.model.Playlist;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Simulates sending push notifications on playlist events.
 */
@Slf4j
@Component
public class PushNotificationObserver implements PlaylistObserver {

    @Override
    public void onPlaylistCreated(Playlist playlist) {
        log.info("[PUSH] 🎵 New playlist created: '{}'", playlist.getName());
    }

    @Override
    public void onSongAdded(Playlist playlist, Long songId) {
        log.info("[PUSH] 🎵 Song {} added to '{}'", songId, playlist.getName());
    }

    @Override
    public void onSongRemoved(Playlist playlist, Long songId) {
        log.info("[PUSH] 🎵 Song {} removed from '{}'", songId, playlist.getName());
    }
}
