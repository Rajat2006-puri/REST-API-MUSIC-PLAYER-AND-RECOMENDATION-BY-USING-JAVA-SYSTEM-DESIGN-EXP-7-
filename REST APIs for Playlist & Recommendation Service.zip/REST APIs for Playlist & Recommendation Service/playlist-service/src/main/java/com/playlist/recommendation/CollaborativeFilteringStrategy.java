package com.playlist.recommendation;

import com.playlist.model.Playlist;
import com.playlist.model.Song;
import com.playlist.repository.PlaylistRepository;
import com.playlist.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Collaborative Filtering (simplified):
 * Finds other users whose playlists overlap with the target user's,
 * then recommends songs those similar users have that the target user doesn't.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CollaborativeFilteringStrategy implements RecommendationStrategy {

    private final PlaylistRepository playlistRepository;
    private final UserRepository userRepository;

    @Override
    public List<Song> recommend(Long userId, int limit) {
        log.debug("CollaborativeFilteringStrategy: recommending for user {}", userId);

        // Songs the target user already has
        Set<Long> userSongIds = playlistRepository.findByOwnerId(userId).stream()
                .flatMap(p -> p.getSongs().stream())
                .map(Song::getId)
                .collect(Collectors.toSet());

        // All other users' playlists
        List<Long> otherUserIds = userRepository.findAll().stream()
                .map(u -> u.getId())
                .filter(id -> !id.equals(userId))
                .collect(Collectors.toList());

        // Score songs by how many other users have them (that the target user doesn't)
        Map<Song, Long> songScore = new HashMap<>();
        for (Long otherId : otherUserIds) {
            playlistRepository.findByOwnerId(otherId).stream()
                    .flatMap(p -> p.getSongs().stream())
                    .filter(s -> !userSongIds.contains(s.getId()))
                    .forEach(s -> songScore.merge(s, 1L, Long::sum));
        }

        return songScore.entrySet().stream()
                .sorted(Map.Entry.<Song, Long>comparingByValue().reversed())
                .limit(limit)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    @Override
    public String getStrategyName() {
        return "COLLABORATIVE_FILTERING";
    }
}
