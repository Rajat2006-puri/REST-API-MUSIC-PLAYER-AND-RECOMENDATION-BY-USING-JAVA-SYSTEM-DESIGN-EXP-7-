# Playlist & Recommendation Service

## Run

```bash
cd playlist-service
mvn spring-boot:run
```

Swagger UI: http://localhost:8080/swagger-ui.html  
H2 Console: http://localhost:8080/h2-console (JDBC URL: `jdbc:h2:mem:playlistdb`)

> Redis is optional. Without it, the app uses in-memory caching automatically.

---

## Sample API Requests

### Playlist APIs

```bash
# Create playlist
curl -X POST http://localhost:8080/api/playlists \
  -H "Content-Type: application/json" \
  -d '{"name":"My Playlist","description":"Favourites","ownerId":1}'

# Get playlist (cached after first call)
curl http://localhost:8080/api/playlists/1

# Update playlist
curl -X PUT http://localhost:8080/api/playlists/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Updated Name","description":"New desc"}'

# Add song to playlist
curl -X POST http://localhost:8080/api/playlists/1/songs/3

# Remove song from playlist
curl -X DELETE http://localhost:8080/api/playlists/1/songs/3

# Delete playlist
curl -X DELETE http://localhost:8080/api/playlists/1
```

### Recommendation APIs

```bash
# Get recommendations (default POPULARITY strategy)
curl "http://localhost:8080/api/recommendations?userId=1&limit=5" \
  -H "X-User-Id: user1"

# Get personalized (all strategies merged)
curl "http://localhost:8080/api/recommendations/personalized?userId=1" \
  -H "X-User-Id: user1"

# Switch strategy: POPULARITY | CONTENT_BASED | COLLABORATIVE_FILTERING
curl -X POST "http://localhost:8080/api/recommendations/strategy?strategy=CONTENT_BASED"

# Check active strategy
curl http://localhost:8080/api/recommendations/strategy
```

### Rate Limit

```bash
# Check rate limit status
curl http://localhost:8080/api/rate-limit/status -H "X-User-Id: user1"

# Trigger rate limit (run 11+ times quickly)
for i in {1..12}; do
  curl -s "http://localhost:8080/api/recommendations?userId=1" -H "X-User-Id: user1" | jq .success
done
```

### Songs

```bash
# List all songs
curl http://localhost:8080/api/songs

# Create a song
curl -X POST http://localhost:8080/api/songs \
  -H "Content-Type: application/json" \
  -d '{"title":"New Song","artist":"Artist","genre":"POP","playCount":0,"rating":4.5}'
```

---

## Design Patterns

### Strategy Pattern (Recommendations)
- `RecommendationStrategy` interface with 3 implementations
- `RecommendationContext` holds the active strategy and allows runtime switching
- Switch via `POST /api/recommendations/strategy?strategy=CONTENT_BASED`

### Observer Pattern (Playlist Events)
- `PlaylistObserver` interface
- `EmailNotificationObserver` + `PushNotificationObserver` auto-registered
- Triggered on: playlist created, song added, song removed

### Cache-Aside Pattern (Redis)
1. Request hits controller → service calls `@Cacheable`
2. Spring checks Redis — cache HIT returns immediately
3. Cache MISS → DB query → result stored in Redis with TTL
4. On update/delete → `@CacheEvict` removes stale entry

### Token Bucket Rate Limiting
- Each user gets a bucket with `capacity=10` tokens
- Refills `10 tokens / 60 seconds`
- Exceeding limit returns HTTP 429 with `X-RateLimit-*` headers
